.. _glossary:

Glossary
========

.. glossary::
   :sorted:

   Pyramid
      A `web framework <http://pylonshq.com/pyramid>`_.

   transaction
      A database transaction comprises a unit of work performed within a
      database management system.  Within this context it is also the
      name of a `Python distribution <http://pypi.python.org/pypi/transaction>`_.
